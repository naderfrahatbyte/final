package app.goals

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.style.StrikethroughSpan
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// نافذة عائمة لاستعراض القوائم وإنجاز مهامها دون فتح التطبيق
class ListsActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var pal: Pal
    private val open = HashSet<String>()
    private var init = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Lang.load(this)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        pal = PalGen.get(this, 85)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = Lang.dir
        box.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 10))
        val sv = ScrollView(this)
        sv.addView(box)
        setContentView(sv)
        Glass.apply(this, pal)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val m = Model(this)
        if (!init) {
            init = true
            for (l in m.lists) if (l.items.any { !it.done }) open.add(l.id)
        }
        fun dp(v: Int): Int = Ui.dp(this, v)
        box.removeAllViews()
        if (m.lists.isEmpty()) {
            box.addView(Ui.tv(this, T("لا قوائم", "No lists"), 15f, pal.muted))
            return
        }
        for ((idx, l) in m.lists.withIndex()) {
            val col = PalGen.tone(pal, l.id)
            val ex = open.contains(l.id)
            val unf = l.items.any { !it.done }

            // عنوان القائمة: نقطة (إن وُجدت مهام غير منجزة) + الاسم كاملًا + سهم للتوسيع/الطي
            val head = LinearLayout(this)
            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            head.setPadding(0, dp(10), 0, dp(10))
            val dot = View(this)
            dot.background = Ui.shape(col, 0, dp(5).toFloat())
            dot.visibility = if (unf) View.VISIBLE else View.INVISIBLE
            head.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)))
            val title = Ui.tv(this, (if (l.pinned) "📌 " else "") + l.title, 16f, if (unf) pal.fg else pal.muted, true)
            title.setPadding(dp(12), 0, dp(12), 0)
            head.addView(title, LinearLayout.LayoutParams(0, Ui.WC, 1f))
            val arrow = Ui.tv(this, if (ex) "▾" else (if (Lang.en) "▸" else "◂"), 24f, pal.fg)
            arrow.setPadding(dp(8), dp(4), dp(8), dp(4))
            head.addView(arrow)
            head.setOnClickListener {
                if (ex) open.remove(l.id) else open.add(l.id)
                render()
            }
            if (idx > 0) {
                val sep = View(this)
                sep.setBackgroundColor(PalGen.alpha(pal.fg, 40))
                box.addView(sep, Ui.lp(Ui.MP, 1))
            }
            box.addView(head, Ui.lp(Ui.MP, Ui.WC))

            if (ex) {
                if (l.items.isEmpty()) {
                    val e = Ui.tv(this, T("فارغة", "Empty"), 14f, pal.muted)
                    e.setPadding(dp(22), dp(4), 0, dp(8))
                    box.addView(e)
                }
                for (it2 in l.items) {
                    val key = "i|" + l.id + "|" + it2.id
                    val row = LinearLayout(this)
                    row.orientation = LinearLayout.HORIZONTAL
                    row.gravity = Gravity.CENTER_VERTICAL
                    row.setPadding(dp(22), 0, 0, 0)
                    val ck = TextView(this)
                    ck.gravity = Gravity.CENTER
                    ck.textSize = 13f
                    if (it2.done) {
                        ck.text = "✓"
                        ck.setTextColor(Color.WHITE)
                        ck.background = Ui.shape(col, 0, dp(11).toFloat())
                    } else {
                        ck.background = Ui.shape(Color.TRANSPARENT, col, dp(11).toFloat(), dp(2))
                    }
                    // مساحة ضغط مريحة حول دائرة الإنجاز
                    val hit = LinearLayout(this)
                    hit.gravity = Gravity.CENTER
                    hit.setPadding(dp(4), dp(10), dp(10), dp(10))
                    hit.addView(ck, LinearLayout.LayoutParams(dp(22), dp(22)))
                    hit.setOnClickListener {
                        startActivity(Intent(this, CelebrateActivity::class.java).putExtra("m", key))
                        Handler(Looper.getMainLooper()).postDelayed({ if (!isFinishing) render() }, 300)
                    }
                    row.addView(hit)
                    val sp = SpannableString(it2.title)
                    if (it2.done) sp.setSpan(StrikethroughSpan(), 0, sp.length, 0)
                    val tt = Ui.tv(this, "", 14f, if (it2.done) pal.muted else pal.fg)
                    tt.text = sp
                    tt.setPadding(dp(6), dp(8), 0, dp(8))
                    tt.setOnClickListener { startActivity(Intent(this, EditActivity::class.java).putExtra("m", key)) }
                    row.addView(tt, LinearLayout.LayoutParams(0, Ui.WC, 1f))
                    box.addView(row, Ui.lp(Ui.MP, Ui.WC))
                }
            }
        }
    }
}
