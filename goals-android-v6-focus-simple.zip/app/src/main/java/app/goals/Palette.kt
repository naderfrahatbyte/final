package app.goals

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Color
import android.os.Build

class Pal(
    val dark: Boolean,
    val fg: Int,
    val muted: Int,
    val accent: Int,
    val warn: Int,
    val tones: IntArray,
    val glass: Int,
    val line: Int
)

object PalGen {
    // Focus uses the same fixed palette as the WebView rather than wallpaper-dependent colors.
    fun focus(): Pal = Pal(
        true,
        Color.parseColor("#f5efe6"),
        Color.parseColor("#aaa3b5"),
        Color.parseColor("#d4a95a"),
        Color.parseColor("#e07a6a"),
        intArrayOf(Color.parseColor("#d4a95a"), Color.parseColor("#65b891"), Color.parseColor("#a98bd8"), Color.parseColor("#7fa8e8"), Color.parseColor("#5bb8a8"), Color.parseColor("#9cc27a")),
        Color.parseColor("#171222"),
        Color.parseColor("#352d43")
    )

    fun mix(a: Int, b: Int, t: Float): Int {
        fun f(x: Int, y: Int) = (x + (y - x) * t).toInt()
        return Color.rgb(f(Color.red(a), Color.red(b)), f(Color.green(a), Color.green(b)), f(Color.blue(a), Color.blue(b)))
    }

    fun alpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun hsv(h: Float, s: Float, v: Float): Int =
        Color.HSVToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))

    fun get(c: Context, tr: Int): Pal {
        var p = Color.parseColor("#14246B")
        var s = 0
        var haveS = false
        if (Build.VERSION.SDK_INT >= 27) {
            try {
                val wc = WallpaperManager.getInstance(c).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
                if (wc != null) {
                    p = wc.primaryColor.toArgb()
                    val sc = wc.secondaryColor
                    if (sc != null) {
                        s = sc.toArgb()
                        haveS = true
                    }
                }
            } catch (e: Exception) {
            }
        }
        val lum = (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)).toInt()
        val scrim = (100 - tr) * 0.8
        val dark = lum * (1 - scrim / 100.0) < 140
        val hp = FloatArray(3)
        Color.colorToHSV(p, hp)
        val hs = FloatArray(3)
        if (haveS) Color.colorToHSV(s, hs) else {
            hs[0] = hp[0] + 40f
            hs[1] = 0.6f
            hs[2] = 0.9f
        }
        val baseH = if (hp[1] > 0.15f) hp[0] else hs[0]
        val accent = hsv(hs[0], hs[1].coerceIn(0.45f, 0.8f), if (dark) 0.97f else 0.45f)
                val tones = IntArray(6) { k -> hsv(baseH + (k - 2) * 9f, 0.32f + (k % 3) * 0.08f, if (dark) 0.95f - (k % 3) * 0.07f else 0.42f + (k % 3) * 0.06f) }
        val warn = hsv(baseH + 160f, 0.55f, if (dark) 0.98f else 0.5f)
        val fg = if (dark) Color.WHITE else Color.parseColor("#101828")
        val muted = if (dark) Color.argb(170, 255, 255, 255) else Color.argb(150, 16, 24, 40)
        val gl = mix(p, if (dark) Color.BLACK else Color.WHITE, 0.55f)
        return Pal(dark, fg, muted, accent, warn, tones, alpha(gl, 215), alpha(fg, 55))
    }

    fun tone(pal: Pal, key: String): Int = pal.tones[Math.floorMod(key.hashCode(), 6)]

    fun goalColor(m: Model, pal: Pal, g: G): Int {
        val key = if (g.parent.isNotEmpty() && m.byId[g.parent] != null) g.parent else g.id
        return tone(pal, key)
    }
}
