package app.goals

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebMessage
import android.net.Uri
import org.json.JSONObject
import android.os.Build
import java.lang.ref.WeakReference

class MainActivity : Activity() {
    companion object {
        private var current: WeakReference<MainActivity>? = null
        fun notifyFocusChanged() {
            current?.get()?.let { a ->
                a.postWebEvent("focus_changed", mapOf("state" to (FocusStore.session?.state ?: "none"), "balance" to FocusStore.fmtFloor(FocusStore.bal)))
            }
        }
    }

    private var web: WebView? = null
    private var started = false
    private var pageReady = false
    private val pendingEvents = ArrayList<String>()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = WeakReference(this)
        applySystemBars()
        val w = WebView(this)
        w.setBackgroundColor(Color.parseColor("#0a0712"))
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(this), "Android")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                pageReady = true
                val queued = pendingEvents.toList()
                pendingEvents.clear()
                queued.forEach { sendWebMessage(it) }
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "http" || u.scheme == "https") {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                    return true
                }
                return false
            }
        }
        w.loadUrl("file:///android_asset/index.html")
        setContentView(w)
        web = w
    }

    private fun applySystemBars() {
        val bg = Color.parseColor("#0a0712")
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.setBackgroundColor(bg)
        if (Build.VERSION.SDK_INT >= 29) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        // Keep light/dark icon appearance managed by the system theme; avoid transient white bars.
        window.decorView.systemUiVisibility = 0
    }

    override fun onResume() {
        super.onResume()
        applySystemBars()
        if (started) postWebEvent("focus_returned")
        started = true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val tab = intent.getStringExtra("tab")
        postWebEvent("focus_returned", if (tab.isNullOrBlank()) null else mapOf("tab" to tab))
    }

    fun postWebEvent(type: String, data: Map<String, String>? = null) {
        val payload = JSONObject().put("type", type)
        data?.forEach { (k, v) -> payload.put(k, v) }
        val message = payload.toString()
        val target = web
        if (!pageReady || target == null) { pendingEvents.add(message); return }
        runOnUiThread { sendWebMessage(message) }
    }

    private fun sendWebMessage(message: String) {
        val target = web ?: run { pendingEvents.add(message); return }
        try { target.postWebMessage(WebMessage(message), Uri.parse("*")) }
        catch (_: Exception) { pendingEvents.add(message) }
    }

    override fun onDestroy() {
        if (current?.get() === this) current = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Backup.result(this, requestCode, resultCode, data)
    }
}

class Bridge(private val a: MainActivity) {
    private val c: Context = a

    @JavascriptInterface
    fun load(): String = c.getSharedPreferences("g", 0).getString("d", "") ?: ""

    @JavascriptInterface
    fun save(s: String) {
        c.getSharedPreferences("g", 0).edit().putString("d", s).apply()
        GoalsWidget.refresh(c)
    }

    @JavascriptInterface
    fun exportBackup() {
        a.runOnUiThread { Backup.export(a) }
    }

    @JavascriptInterface
    fun importBackup() {
        a.runOnUiThread { Backup.importFile(a) }
    }

    // مكافأة Focus عند إنجاز مهمة من واجهة الويب (تُنفَّذ على الخيط الرئيسي لتجنّب التعارض مع الخدمة)
    @JavascriptInterface
    fun focusReward(amount: Double, title: String, ref: String): Double {
        val out = DoubleArray(1)
        val latch = java.util.concurrent.CountDownLatch(1)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                FocusStore.init(a)
                out[0] = FocusStore.add(amount, title, ref, false)
            } catch (e: Exception) {
            }
            latch.countDown()
        }
        try {
            latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: Exception) {
        }
        return out[0]
    }

    @JavascriptInterface
    fun openFocus(fromTab: String) {
        a.runOnUiThread {
            a.startActivity(Intent(a, FocusActivity::class.java).putExtra("from", "tab").putExtra("tab", fromTab))
        }
    }

    @JavascriptInterface
    fun getPref(k: String): Int = if (Store.flag(c, k)) 1 else 0

    @JavascriptInterface
    fun setPref(k: String, v: Int) {
        Store.setFlag(c, k, v != 0)
    }
}
