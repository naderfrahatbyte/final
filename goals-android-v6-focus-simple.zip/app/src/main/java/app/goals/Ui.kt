package app.goals

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

object Ui {
    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun tv(c: Context, t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(c)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    fun shape(fill: Int, stroke: Int, r: Float, sw: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = r
        if (sw > 0) g.setStroke(sw, stroke)
        return g
    }

    fun btn(c: Context, t: String, bg: Int, fg: Int): TextView {
        val v = tv(c, t, 16f, fg, true)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12))
        v.background = shape(bg, 0, dp(c, 12).toFloat())
        return v
    }

    fun chip(c: Context, t: String, pal: Pal, on: Boolean): TextView {
        val v = tv(c, t, 14f, if (on) pal.accent else pal.muted, on)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
        v.background = shape(if (on) PalGen.alpha(pal.accent, 45) else Color.TRANSPARENT, pal.line, dp(c, 18).toFloat(), dp(c, 1).coerceAtLeast(1))
        return v
    }

    fun lp(w: Int, h: Int, top: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(w, h)
        l.topMargin = top
        return l
    }

    val MP = ViewGroup.LayoutParams.MATCH_PARENT
    val WC = ViewGroup.LayoutParams.WRAP_CONTENT
}

object Glass {
    fun apply(a: Activity, pal: Pal, frac: Float = 0.92f) {
        val d = a.resources.displayMetrics.density
        val bg = GradientDrawable()
        bg.setColor(pal.glass)
        bg.cornerRadius = 26 * d
        bg.setStroke(d.toInt().coerceAtLeast(1), pal.line)
        a.window.setBackgroundDrawable(bg)
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                a.window.setBackgroundBlurRadius((45 * d).toInt())
            } catch (e: Exception) {
            }
        }
        a.window.setLayout((a.resources.displayMetrics.widthPixels * frac).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}

object Backup {
    const val EXPORT = 7101
    const val IMPORT = 7102

    fun export(a: Activity) {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/json"
        i.putExtra(Intent.EXTRA_TITLE, "ahdaf-backup-" + dateStr(todayDay()) + ".json")
        a.startActivityForResult(i, EXPORT)
    }

    fun importFile(a: Activity) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        a.startActivityForResult(i, IMPORT)
    }

    fun result(a: Activity, req: Int, res: Int, data: Intent?) {
        if (res != Activity.RESULT_OK || data == null) return
        val u = data.data ?: return
        try {
            if (req == EXPORT) {
                a.contentResolver.openOutputStream(u)?.use { val full = JSONObject(Store.data(a).toString())
                    full.put("focus", FocusStore.snapshot(a))
                    it.write(full.toString().toByteArray(Charsets.UTF_8)) }
                Toast.makeText(a, T("تم حفظ النسخة الاحتياطية", "Backup saved"), Toast.LENGTH_SHORT).show()
            } else if (req == IMPORT) {
                val txt = a.contentResolver.openInputStream(u)?.use { String(it.readBytes(), Charsets.UTF_8) } ?: return
                val o = JSONObject(txt)
                if (!o.has("goals") && !o.has("loose") && !o.has("lists")) {
                    Toast.makeText(a, T("الملف غير صالح", "Invalid file"), Toast.LENGTH_SHORT).show()
                    return
                }
                val fo = o.optJSONObject("focus")
                val ga = o.optJSONArray("goals")
                var tasks = o.optJSONArray("loose")?.length() ?: 0
                for (i in 0 until (ga?.length() ?: 0)) tasks += ga?.optJSONObject(i)?.optJSONArray("tasks")?.length() ?: 0
                val msg = T(
                    "سيتم استبدال بياناتك الحالية بمحتوى الملف: " + (ga?.length() ?: 0) + " أهداف، " + tasks + " مهام، " + (o.optJSONArray("lists")?.length() ?: 0) + " قوائم.\n",
                    "Your current data will be replaced by the file: " + (ga?.length() ?: 0) + " goals, " + tasks + " tasks, " + (o.optJSONArray("lists")?.length() ?: 0) + " lists.\n"
                ) + (if (fo != null) T("بيانات Focus ستُستبدل أيضًا بما في الملف.", "Focus data will also be replaced by the file's.")
                else T("بيانات Focus الحالية ستبقى كما هي.", "Your current Focus data stays as it is."))
                AlertDialog.Builder(a)
                    .setTitle(T("استيراد نسخة احتياطية", "Import backup"))
                    .setMessage(msg)
                    .setPositiveButton(T("استبدال", "Replace")) { _, _ ->
                        if (fo != null) FocusStore.restore(a, fo)
                        o.remove("focus")
                        Store.save(a, o)
                        GoalsWidget.refresh(a)
                        (a as? MainActivity)?.postWebEvent("data_changed")
                        Toast.makeText(a, T("تم الاستيراد", "Imported"), Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton(T("إلغاء", "Cancel"), null)
                    .show()
            }
        } catch (e: Exception) {
            Toast.makeText(a, T("تعذّر تنفيذ العملية", "Something went wrong"), Toast.LENGTH_SHORT).show()
        }
    }
}
